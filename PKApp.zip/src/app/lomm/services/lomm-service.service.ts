// tslint:disable:max-line-length
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})

export class LommService {

  constructor() { }
}
