import { C_QLIK_APP_FILTER_DIMENSION_VALUE_DEFAULT } from './qlik_server_parameters';

export const C_ALL_HOSPITAL_KEY = 'BLANK';
export const C_DEFAULT_HOSPITAL_FITLER_SELECTION = `${C_QLIK_APP_FILTER_DIMENSION_VALUE_DEFAULT} - All Hospitals`;
