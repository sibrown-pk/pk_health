export interface IAppNavigation {
    label: string;
    url: string;
}