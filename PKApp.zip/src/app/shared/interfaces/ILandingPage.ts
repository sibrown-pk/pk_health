
export interface IQLink {
    name: string;
    link: string;
    icon: string;
}