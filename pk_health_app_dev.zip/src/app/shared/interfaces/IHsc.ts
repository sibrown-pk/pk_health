export interface IHospitalData {
    Division: string;
    Hospital: string;
    isDefault: boolean;
}